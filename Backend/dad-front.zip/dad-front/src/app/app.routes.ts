import { Routes } from '@angular/router';
import { Home } from './pages/home/home';
import { Recetas } from './pages/recetas/recetas';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: Home },
  { path: 'recetas', component: Recetas },
  { path: '', redirectTo: 'recetas', pathMatch: 'full' }
];
