import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RecetasService, Receta } from '../../core/services/recetas.service';

@Component({
  selector: 'app-recetas',
  standalone: true,
  templateUrl: './recetas.html',
  styleUrls: ['./recetas.scss'],
  imports: [CommonModule, FormsModule]
})
export class Recetas implements OnInit {
  recetas: Receta[] = [];
  recetaActual: Receta = this.nuevaReceta();

  constructor(private recetasService: RecetasService) {}

  ngOnInit(): void {
    this.cargarRecetas();
  }

  nuevaReceta(): Receta {
    return {
      productoId: 0,
      descripcion: '',
      cantidad: 0,
      unidadMedida: '',
      cantidadDisponible: 0,
      menu: { id: 0 }
    };
  }

  cargarRecetas(): void {
    this.recetasService.getAll().subscribe({
      next: (data) => this.recetas = data,
      error: (err) => console.error('Error al cargar', err)
    });
  }

  guardarReceta() {
    if (this.recetaActual.id) {
      this.recetasService.update(this.recetaActual.id, this.recetaActual)
        .subscribe(() => this.cargarRecetas());
    } else {
      this.recetasService.create(this.recetaActual)
        .subscribe(() => this.cargarRecetas());
    }
    this.recetaActual = this.nuevaReceta();
  }

  editar(receta: Receta) {
    this.recetaActual = { ...receta };
  }

  eliminar(id: number) {
    this.recetasService.delete(id).subscribe(() => this.cargarRecetas());
  }
}
