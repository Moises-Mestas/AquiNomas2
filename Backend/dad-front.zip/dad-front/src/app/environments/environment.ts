export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:9000/'  // cambia esto según tu backend local
};
