import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Receta {
  id?: number;
  productoId: number;
  descripcion: string;
  cantidad: number;
  unidadMedida: string;
  cantidadDisponible: number;
  menu: {
    id: number;
    nombre?: string; // lo usas en HTML
  };
  producto?: {
    id: number;
    nombre?: string; // lo usas en HTML
  };
}
@Injectable({ providedIn: 'root' })
export class RecetasService {
  private baseUrl = 'http://localhost:9000/recetas';

  constructor(private http: HttpClient) {}

  getAll(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  create(receta: any): Observable<any> {
    return this.http.post(this.baseUrl, receta);
  }

  update(id: number, receta: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/${id}`, receta);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}

