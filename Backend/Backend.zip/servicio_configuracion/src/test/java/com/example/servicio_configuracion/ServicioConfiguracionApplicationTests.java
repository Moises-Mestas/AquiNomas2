package com.example.servicio_configuracion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioConfiguracionApplicationTests {

    @Test
    void contextLoads() {
    }

}
