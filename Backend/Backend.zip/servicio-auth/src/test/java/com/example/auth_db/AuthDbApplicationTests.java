package com.example.auth_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
