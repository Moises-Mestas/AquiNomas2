package com.example.pedido_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioPedido2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
