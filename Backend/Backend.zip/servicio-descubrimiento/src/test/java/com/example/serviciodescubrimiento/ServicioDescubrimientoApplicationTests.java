package com.example.serviciodescubrimiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioDescubrimientoApplicationTests {

    @Test
    void contextLoads() {
    }

}
