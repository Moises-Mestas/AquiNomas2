package com.example.serviciopedido.entity;

public enum EstadoPedido {
    CANCELADO, COMPLETADO, INICIADO, PENDIENTE;
}
