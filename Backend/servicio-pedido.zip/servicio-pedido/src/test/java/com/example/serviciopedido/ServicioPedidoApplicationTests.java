package com.example.serviciopedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioPedidoApplicationTests {

    @Test
    void contextLoads() {
    }

}
