package com.example.servicioventa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicioVentaApplicationTests {

    @Test
    void contextLoads() {
    }

}
